import React from 'react'

const Header = () => {
  return (
    <>
        <h1>TodoList</h1>
        <div>
            <span>0 more,</span>
            <span>0 done</span>
        </div>
    </>
  )
}

export default Header