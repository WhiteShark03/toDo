import React from 'react'
import Button from '../Button'

const Todo = ({todoObj}) => {

  return (
    <li>
        <span>{todoObj.todoText}</span>
        <div>
            <Button>done</Button>
            <Button>edit</Button>
            <Button>delete</Button>
        </div>
    </li>
  )
}

export default Todo