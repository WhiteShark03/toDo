import React from 'react'

const StatusBar = () => {
  return (
    <div>
        <div>
            <button type="button">All</button>
            <button type="button">ACtive</button>
            <button type="button">Done</button>
        </div>
        <input type="text" placeholder="search"/>
    </div>
  )
}

export default StatusBar