import React, { useState } from 'react'
import Header from './components/Header';
import StatusBar from './components/StatusBar/StatusBar';
import TodoList from './components/TodoList';
import AddForm from './components/AddForm';

function App() {
  const [todos, setTodos] = useState([])
  const [todoText, setTodoText] = useState('')

  return (
  <div className='App'>
    <div className='container'>
      <Header/>
      <StatusBar/>
      <TodoList todos={todos}/>
      <AddForm  setTodos={setTodos} setTodoText={setTodoText} todoText={todoText}/>
    </div>
  </div>
  );
}

export default App;
